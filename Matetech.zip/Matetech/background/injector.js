chrome.storage.sync.get(["work"], function(items){
  if (items[0]){
    if (items[0]["work"]){
      chrome.declarativeNetRequest.updateDynamicRules(
        {
          addRules: [
            {
              action: {
                type: "redirect",
                "redirect": { "url": chrome.runtime.getURL("content_scripts/index.js") }
              },
              condition: {
                urlFilter: "https://xn--80asehdb.xn----7sb3aehik9cm.xn--p1ai/_nuxt/9c72125.js", // block URLs that starts with this
                domains: ["xn--80asehdb.xn----7sb3aehik9cm.xn--p1ai"], // on this domain
              },
              id: 1,
              priority: 1,
            },
          ],
          removeRuleIds: [1], // this removes old rule if any
        },
        () => {
          console.log("Redirect added!");
        }
      );
    }
    else{
      chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: [1] });
    }
  }
});
chrome.declarativeNetRequest.onRuleMatchedDebug.addListener((e) => {
    const msg = `Navigation to ${e.request.url} redirected on tab ${e.request.tabId}.`;
    console.log(msg);
});

chrome.runtime.onMessage.addListener((message) => {
  switch (message.method) {
    case "add":
      chrome.declarativeNetRequest.updateDynamicRules(
        {
          addRules: [
            {
              action: {
                type: "redirect",
                "redirect": { "url": chrome.runtime.getURL("content_scripts/index.js") }
              },
              condition: {
                urlFilter: "https://xn--80asehdb.xn----7sb3aehik9cm.xn--p1ai/_nuxt/9c72125.js", // block URLs that starts with this
                domains: ["xn--80asehdb.xn----7sb3aehik9cm.xn--p1ai"], // on this domain
              },
              id: 1,
              priority: 1,
            },
          ],
          removeRuleIds: [1], // this removes old rule if any
        },
        () => {
          console.log("Redirect added!");
        }
      );
      chrome.storage.sync.set({ "work": true }, function(){});
      break;
    case "remove":
      chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: [1] });
      chrome.storage.sync.set({ "work": false }, function(){});
      break;
  }
});